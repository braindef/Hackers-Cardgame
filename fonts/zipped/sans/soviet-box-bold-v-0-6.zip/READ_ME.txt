FYI: 

This font is in it's early beta stage. 
Many glyphs and characters are missing.

All kinds of oddities, weird spacing and  
kerning problems are inevitable.

Have fun!